# SchoolLife

A 2D pixel-art jump'n'run built with React, TanStack Start and a hand-written canvas engine.

## Getting started

```bash
bun install
bun run dev
```

## Environment

Create a `.env` file:

```
VITE_SUPABASE_URL=your-project-url
VITE_SUPABASE_PUBLISHABLE_KEY=your-publishable-key
```

Game & pixel art by LxcxStudios.
