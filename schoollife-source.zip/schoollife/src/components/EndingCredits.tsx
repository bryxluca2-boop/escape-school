import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";

/** Filmabspann: schwarzer Screen, langsam hochlaufende Pixel-Credits. */
export function EndingCredits({ onDone }: { onDone: () => void }) {
  const { t } = useI18n();
  const [showSkip, setShowSkip] = useState(false);
  const DURATION = 34000;

  useEffect(() => {
    const a = setTimeout(() => setShowSkip(true), 1500);
    const b = setTimeout(onDone, DURATION + 2000);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, [onDone]);

  const lines: { text: string; cls: string }[] = [
    { text: t("credits.presents"), cls: "text-[10px] text-[color:var(--color-muted-foreground)]" },
    { text: "SCHOOLLIFE", cls: "text-2xl md:text-4xl text-[color:var(--color-secondary)]" },
    { text: t("credits.by"), cls: "text-xs text-[color:var(--color-accent)]" },
    { text: "", cls: "" },
    { text: t("credits.director"), cls: "text-[10px]" },
    { text: "LXCX", cls: "text-base text-[color:var(--color-primary)]" },
    { text: "", cls: "" },
    { text: t("credits.game"), cls: "text-[10px]" },
    { text: t("credits.music"), cls: "text-[10px]" },
    { text: t("credits.engine"), cls: "text-[10px]" },
    { text: "", cls: "" },
    { text: t("credits.end"), cls: "text-lg text-[color:var(--color-secondary)]" },
    { text: "", cls: "" },
    { text: "", cls: "" },
    { text: t("credits.thanks"), cls: "text-sm md:text-lg text-[color:var(--color-accent)]" },
    { text: "LXCXSTUDIOS", cls: "text-[10px] text-[color:var(--color-muted-foreground)]" },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black overflow-hidden scanlines">
      <style>{`
        @keyframes sl-roll { 0% { transform: translateY(100vh); } 100% { transform: translateY(-130%); } }
        .sl-roll { animation: sl-roll ${DURATION}ms linear forwards; }
      `}</style>
      <div className="sl-roll w-full px-6 text-center flex flex-col items-center gap-5">
        {lines.map((l, i) => (
          <div key={i} className={l.cls} style={{ minHeight: 8 }}>{l.text}</div>
        ))}
      </div>
      {showSkip && (
        <button
          onClick={onDone}
          className="btn-pixel btn-pixel-secondary absolute bottom-6 right-6"
          style={{ padding: "8px 12px", fontSize: 10 }}
        >
          {t("credits.thanks") ? "OK" : "OK"}
        </button>
      )}
    </div>
  );
}
